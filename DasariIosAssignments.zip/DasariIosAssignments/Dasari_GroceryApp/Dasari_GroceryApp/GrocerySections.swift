//
//  AppDelegate.swift
//  Dasari_GroceryApp
//
//  Created by Dasari,Venkata Sai Ram on 8/17/1944 Saka.
//

import Foundation


struct GrocerySections{
    var section = ""
    var items_Array:[GroceryItem] = []
}


struct GroceryItem{
    var itemName : String = ""
    var itemImage : String = ""
    var itemInfo : String = ""
}

   

let Section1 = GrocerySections(section:"Hero",
items_Array:[GroceryItem(itemName:"Pawan Kalyan",itemImage:"pawan",itemInfo:"Pawan Kalyan (born Konidela Kalyan Babu; 2 September 1971) is an Indian actor, filmmaker, philanthropist, and politician. His films are predominantly in Telugu cinema. Kalyan is the younger brother of actor-ex. politician Chiranjeevi, and made his debut in the 1996 film Akkada Ammayi Ikkada Abbayi."),
GroceryItem(itemName: "Prabhas", itemImage: "prabhas", itemInfo: "Uppalapati Venkata Suryanarayana Prabhas Raju, known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema, Prabhas has featured in Forbes India's Celebrity 100 list three times since 2015 based on his income and popularity."),
GroceryItem(itemName: "Bala Krishna", itemImage: "balayya", itemInfo: "Nandamuri Balakrishna (born 10 June 1960), simply known as Balakrishna or Balayya or NBK is an Indian actor, producer and politician. He appeared in more than 100 Telugu films over forty years in a variety of roles and established himself as one of the leading actors of Telugu cinema."),
GroceryItem(itemName: "Allu Arjun", itemImage: "allu arjun", itemInfo: "Allu Arjun is an Indian actor who predominantly works in Telugu films. He is one of the highest paid actors in South India and is also known for his dancing abilities. Allu is a recipient of several awards, including five Filmfare Awards South and five Nandi Awards."),
GroceryItem(itemName: "Mahesh Babu", itemImage: "mahesh", itemInfo: "Ghattamaneni Mahesh Babu was born on 9 August 1975 in a Telugu family in Madras (now Chennai), Tamil Nadu, India. He is the fourth of the five children of Telugu actor Krishna and Indira, after Ramesh Babu, Padmavathi, and Manjula and before Priyadarshini.")])

let Section2 = GrocerySections(section:"Salads",
items_Array:[GroceryItem(itemName:"Green Salad",itemImage:"greensalad",itemInfo:"Salad greens contain Vitamin A, Vitamin C, beta-carotene, calcium, folate, fiber, and phytonutrients (see Table 1). Leafy vegetables are a good choice for a healthful diet because they do not contain cholesterol and are naturally low in calories and sodium."),
GroceryItem(itemName: "Vegetable Salad", itemImage: "vegsalad", itemInfo: "Vegetable salads may be marinated or sauced mixtures of raw or cooked vegetables. They are commonly based on tomatoes, green beans, cucumbers, beets, and mushrooms. Cole slaw (from the Dutch kool, “cabbage”) is made of shredded or chopped cabbage with a mayonnaise or vinegar-based dressing. Some Middle Eastern salads are puréed or finely chopped cucumbers, eggplants, or chickpeas, mixed with tahini or yogurt. Salade russe is a variety of chopped cooked vegetables and potatoes bound with mayonnaise. Although they are sometimes served as hors d’oeuvres, salads of this type usually take the place of hot or cold vegetable side dishes."),
GroceryItem(itemName: "Pasta Salad", itemImage: "pastasalad", itemInfo: "Pasta salad is a salad dish prepared with one or more types of pasta, almost always chilled, and most often tossed in a vinegar, oil, or mayonnaise-based dressing. It is typically served as an appetizer, side dish or a main course. "),
GroceryItem(itemName: "Fruit Salad", itemImage: "fruitsalad", itemInfo: "Common ingredients used in fruit salads include strawberries, pineapple, honeydew, watermelon, grapes, and kiwifruit. Various recipes may call for the addition of nuts, fruit juices, certain vegetables, yogurt, or other ingredients. One variation is a Waldorf-style fruit salad, which uses a mayonnaise-based sauce."),
GroceryItem(itemName: "Caesar Salad", itemImage: "causarsalad", itemInfo: "Caesar salad is traditionally made with romaine lettuce, croutons, Parmesan cheese, and a creamy dressing made with anchovies and egg yolks. You can add variety and nutrients by using other lettuces, vegetables, and lean proteins.")])

let Section3 = GrocerySections(section:"Meat",
items_Array:[GroceryItem(itemName:"Beef",itemImage:"beef",itemInfo:"Beef is the culinary name for meat from cattle. In prehistoric times, humankind hunted aurochs and later domesticated them. Since that time, numerous breeds of cattle have been bred specifically for the quality or quantity of their meat."),
GroceryItem(itemName: "Pork", itemImage: "pork", itemInfo: "Pork is the culinary name for the meat of the domestic pig. It is the most commonly consumed meat worldwide, with evidence of pig husbandry dating back to 5000 BCE. Pork is eaten both freshly cooked and preserved; curing extends the shelf life of pork products."),
GroceryItem(itemName: "Lamb", itemImage: "lamb", itemInfo: "Lamb is a type of red meat that comes from young sheep. Not only is it a rich source of high-quality protein, but it is also an outstanding source of many vitamins and minerals, including iron, zinc, and vitamin B12. Because of this, regular consumption of lamb may promote muscle growth, maintenance, and performance. "),
GroceryItem(itemName: "Turkey", itemImage: "turkey", itemInfo: "Turkey is low in fat and high in protein. It is an inexpensive source of iron, zinc, phosphorus, potassium and B vitamins. A serving of turkey is a 2 to 3-ounce cooked portion. The Food Guide Pyramid suggests 2 to 3 servings from the meat group each day."),
GroceryItem(itemName: "Quail", itemImage: "quail", itemInfo: "Quail meat, for instance, is highly nutritious, giving you protein, calcium, iron and zinc. Quail eggs are high in protein and choline– good for your brain! As for vitamins, when you eat quail you get vitamins B, D, A, and K.")])

let Section4 = GrocerySections(section:"Breakfast",
items_Array:[GroceryItem(itemName:"Dosa",itemImage:"Dosa",itemInfo:"A dosa is a thin flat bread originating from South India, made from a fermented batter predominantly consisting of lentils and rice. Its main ingredients are rice and black gram, ground together in a fine, smooth batter with a dash of salt, then fermented."),
GroceryItem(itemName: "Idly", itemImage: "Idly", itemInfo: "Idli or idly are a type of savoury rice cake, originating from the Indian subcontinent, popular as breakfast foods in Southern India and in Sri Lanka. The cakes are made by steaming a batter consisting of fermented black lentils and rice."),
GroceryItem(itemName: "Poori", itemImage: "Poori", itemInfo: "Puri is a deep-fried bread made from unleavened whole-wheat flour that originated in the Indian subcontinent. It is eaten for breakfast or as a snack or light meal. It is usually served with a savory curry or bhaji, as in puri bhaji, but may also be eaten with sweet dishes."),
GroceryItem(itemName: "Upma", itemImage: "Upma", itemInfo: "Upma, uppumavu or uppittu is a dish originating from the Indian subcontinent, most common in Andhra Pradesh, Tamil Nadu, Telangana, Karnataka, Maharashtrian and Sri Lankan Tamil breakfast, cooked as a thick porridge from dry-roasted semolina or coarse rice flour."),
GroceryItem(itemName: "Chapathi", itemImage: "Chapathi", itemInfo: "Chapati, also known as roti, rotli, safati, shabaati, phulka, chapo, and roshi, is an unleavened flatbread originating from the Indian subcontinent and staple in India, Nepal, Bangladesh, Pakistan, Sri Lanka, East Africa, Arabian Peninsula and the Caribbean.")])

let Section5 = GrocerySections(section:"Fruits",
items_Array:[GroceryItem(itemName:"Orange",itemImage:"orange",itemInfo:"An orange is a fruit of various citrus species in the family Rutaceae (see list of plants known as orange); it primarily refers to Citrus × sinensis, which is also called sweet orange, to distinguish it from the related Citrus × aurantium, referred to as bitter orange."),
GroceryItem(itemName: "Guava", itemImage: "guava", itemInfo: "Guava (/ˈɡwɑːvə/) is a common tropical fruit cultivated in many tropical and subtropical regions. The common guava Psidium guajava (lemon guava, apple guava) is a small tree in the myrtle family (Myrtaceae), native to Mexico, Central America, the Caribbean and northern South America."),
GroceryItem(itemName: "Grape", itemImage: "grape", itemInfo: "A grape is a fruit, botanically a berry, of the deciduous woody vines of the flowering plant genus Vitis. Grapes are a non-climacteric type of fruit, generally occurring in clusters."),
GroceryItem(itemName: "Mango", itemImage: "mango", itemInfo: "Mangifera indica, commonly known as mango, is a species of flowering plant in the family Anacardiaceae. It is a large fruit tree, capable of growing to a height of 30 metres (100 feet). There are two distinct genetic populations in modern mangoes – the Indian type and the Southeast Asian type."),
GroceryItem(itemName: "Apple", itemImage: "apple", itemInfo: "An apple is an edible fruit produced by an apple tree (Malus domestica). Apple trees are cultivated worldwide and are the most widely grown species in the genus Malus. The tree originated in Central Asia, where its wild ancestor, Malus sieversii, is still found today.")])


let groceries = [Section1, Section2, Section3, Section4, Section5]
