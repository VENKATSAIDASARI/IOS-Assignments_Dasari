//
//  AppDelegate.swift
//  Dasari_GroceryApp
//
//  Created by Dasari,Venkata Sai Ram on 8/17/1944 Saka.
//

import UIKit

class GroceryItemsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var itemname : GrocerySections?

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var prototypeCell = groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
        prototypeCell.textLabel?.text = itemname!.items_Array[indexPath.row].itemName
        return prototypeCell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        GrocerySection.count;
        //(itemname!.items_Array[GroceryItem(itemName: <#T##String#>, itemImage: <#T##String#>, itemInfo: <#T##String#>)].count)
    }
    
    var GrocerySection = groceries
    var GrocerySectionItem = GroceryItem()
    
    @IBOutlet weak var groceryItemsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        groceryItemsTableView.delegate = self
        groceryItemsTableView.dataSource = self
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemInfoSegue"{
            let destination = segue.destination as! ItemInfoViewController
            destination.iteminfo = itemname!.items_Array[(groceryItemsTableView.indexPathForSelectedRow?.row)!]
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
