//
//  AppDelegate.swift
//  Dasari_GroceryApp
//
//  Created by Dasari,Venkata Sai Ram on 8/17/1944 Saka.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        grocerySection.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var prototypeCell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        prototypeCell.textLabel?.text = grocerySection[indexPath.row].section
        return prototypeCell
    }
    
    var grocerySection = groceries
    var grocerySectionItems = GrocerySections()
    
    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemsSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            destination.itemname = grocerySection[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
        }
    }
}

