//
//  ViewController.swift
//  Dasari_SearchApp
//
//  Created by Dasari,Venkata Sai Ram on 7/20/1944 Saka.

//



import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
   
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    var arr = [["pawan kalyan","nani","allu arjun","ram pothineni","prabhas"],["rose","lotus","lilly","gerbera","jasmine"],["Book1","Book2","Book3","Book4","Book5"],["bg","404"]]
    
    var actors = ["actor","hero","movie","film"]
    
    var flowers = ["flowers","wallpaper","garden"]
    
    var books = ["books","story","comics","narration"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prevButton.isHidden = true
        nextButton.isHidden = true
        searchButton.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
        
    }
    
        
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
            
        }
        else{

            prevButton.isEnabled = false
            nextButton.isEnabled = false
            searchButton.isEnabled = true
            resetButton.isHidden = false
    }
    }
    
        
        
    
    
    var artist = [["pawan kalyan","nani","allu arjun","ram pothineni","prabhas"],["Pawan Kalyan is an Indian actor, filmmaker, philanthropist, and politician. His films are predominantly in Telugu cinema. Kalyan is the younger brother of actor-politician Chiranjeevi, and made his debut in the 1996 film Akkada Ammayi Ikkada Abbayi","Ghanta Naveen Babu, known professionally as Nani, is an Indian actor, producer, and television presenter primarily known for his work in Telugu cinema.","Allu Arjun is an Indian actor who works in Telugu films. One of the highest paid actors in India, Arjun is also known for his dancing. He is a recipient of several awards, including five Filmfare Awards South and five Nandi Awards. Allu Arjun made his debut with Gangotri in 2003","Ram Pothineni is an Indian actor who works mostly in Telugu films. He made his feature film debut with the box office hit Devadasu, which won him the Filmfare Award for Best Male Debut – South","Uppalapati Venkata Suryanarayana Prabhas Raju, known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in India, Prabhas has featured in Forbes India's Celebrity 100 list since 2015 based on his income and popularity. "]]
    
    var flower = [["rose","lotus","lilly","gerbera","jasmine"],["A rose is either a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars","Nelumbo nucifera, also known as sacred lotus, Laxmi lotus, Indian lotus, or simply lotus, is one of two extant species of aquatic plant in the family Nelumbonaceae. It is sometimes colloquially called a water lily, though this more often refers to members of the family Nymphaeaceae.","Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. Lilies are a group of flowering plants which are important in culture and literature in much of the world","Gerbera L. is a genus of plants in the Asteraceae family. The first scientific description of a Gerbera was made by J. D. Hooker in Curtis's Botanical Magazine in 1889 when he described Gerbera jamesonii, a South African species also known as Transvaal daisy or Barberton daisy.","Jasmine is a genus of shrubs and vines in the olive family. It contains around 200 species native to tropical and warm temperate regions of Eurasia, Africa, and Oceania. Jasmines are widely cultivated for the characteristic fragrance of their flowers."]]

    var book = [["Book1","Book2","Book3","Book4","Book5"],["The Secret is a 2006 self-help book by Rhonda Byrne, based on the earlier film of the same name. It is based on the belief of the pseudoscientific law of attraction, which claims that thoughts can change a person's life directly. The book alleges energy as assurance of its effectiveness.","Dr. A.P.J. Abdul Kalam: Biography Of A Saintly Scientist book tell us about great indian Scientist,president.Avul Pakir Jainulabdeen Abdul Kalam was an Indian aerospace scientist and statesman who served as the 11th President of India from 2002 to 2007. He was born and raised in Rameswaram, Tamil Nadu and studied physics and aerospace engineering.","In Spider-Man's first story, in Marvel Comics' Amazing Fantasy, no. 15 (1962), American teenager Peter Parker, a poor sickly orphan, is bitten by a radioactive spider. As a result of the bite, he gains superhuman strength, speed, and agility along with the ability to cling to walls","The Marvel Book is an exhilarating journey through the endlessly fascinating, ever-dynamic, and awe-inspiring Marvel Comics universe.The Marvel Book is packed with vivid, carefully sourced artwork, illuminating infographics","Life is boring when you live in the real world, instead of starring in your own book series. Owen knows that better than anyone, what with the real world's homework and chores. But everything changes the day Owen sees the impossible happen—his classmate Bethany climb out of a book in the library."]]
    
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        prevButton.isHidden = false
        nextButton.isHidden = false
        prevButton.isEnabled = false
        nextButton.isEnabled = false
        resetButton.isEnabled = true
        if(actors.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[0][imag1])
            
            topic = 1
            topicInfoText.text = artist[1][text1]
        }
        
        else if(flowers.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[1][imag2])
            
            topic = 2
            topicInfoText.text = flower[1][text2]
        }
        else if(books.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[2][imag3])
            
            topic = 3
            topicInfoText.text = book[1][text3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])

            topicInfoText.text = nil
            
            prevButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
            
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        
        prevButton.isHidden = true
        nextButton.isHidden = true
        topicInfoText.text = nil
        resetButton.isHidden = true
        searchTextField.text = ""
        resultImage.image = UIImage(named: arr[3][0])

        searchButton.isEnabled=false
        
        
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == arr[0].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                
                topicInfoText.text = artist[1][text1]
            }
            else if(imag1 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
                
                topicInfoText.text = artist[1][text1]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
               
                topicInfoText.text = artist[1][text1]
            }
        }
        if(topic == 2){
            if imag2 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                
                topicInfoText.text = flower[1][text2]
            }
            else if(imag2 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                
                topicInfoText.text = flower[1][text2]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
                
                topicInfoText.text = flower[1][text2]
                
            }
        }
        if(topic == 3){
            if imag3 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                
                topicInfoText.text = book[1][text3]
            }
            else if(imag3 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                
                topicInfoText.text = book[1][text3]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
                
                topicInfoText.text = book[1][text3]
                
            }
        }
    }
    

    
    
    
    
    
}


