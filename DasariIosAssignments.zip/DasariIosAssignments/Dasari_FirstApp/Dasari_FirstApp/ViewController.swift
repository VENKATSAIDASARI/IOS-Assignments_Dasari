//
//  ViewController.swift
//  Dasari_FirstApp
//
//  Created by Dasari,Venkata Sai Ram on 9/13/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        var firstName = firstNameTextField.text!
        var lastName = lastNameTextField.text!
        
        var firstChar = firstName.prefix(1)
        var lastChar = lastName.prefix(1)
        
        fullNameLabel.text = "Full Name : \(lastName), \(firstName)"
        initialsLabel.text = "Initials : \(firstChar)\(lastChar)"
        detailsLabel.text = "Details"
        
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        detailsLabel.text = ""
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        
        firstNameTextField.becomeFirstResponder()
    }
    
    
    

}

