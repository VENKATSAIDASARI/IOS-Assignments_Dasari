//
//  ViewController.swift
//  Dasari_WordGuess
//
//  Created by Dasari,Venkata Sai Ram on 8/5/1944 Saka.
//
import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
   
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    @IBOutlet weak var totalWordsLabel: UILabel!
    @IBOutlet weak var userGuessLabel: UILabel!
    @IBOutlet weak var guessLetterField: UITextField!
    @IBOutlet weak var guessLetterButton: UIButton!
    @IBOutlet weak var playAgainButton: UIButton!
    @IBOutlet weak var displayImage : UIImageView!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var hintLabel: UILabel!
    var RemainingWords:Int=0
    var presentWord = 0
    var guessLetter =  ""
    var GuessedWordsuptoNow = ""
    var WordGuessed = 0
    var count1 = 0
    
    var arrWords = [ ["parrot","Bird"],
                         ["comic","Book"],
                         ["ferrari","Car"],
                          ["Rose","Flower"],
                          ["iphone","Mobile Phone"]]
    var arrImages = ["bird","cbook","car","Rose","apple","done"]

    override func viewDidLoad() {
        super.viewDidLoad()
        guessLetterButton.isEnabled = false
                playAgainButton.isHidden = true
        RemainingWords = arrImages.count
        displayImage.isHidden = true
                updateLabels()
        statusLabel.text = "This is a status lable of App"
                userGuessLabel.text = ""
        WordGuessingUpdate(presentWord)
    }
    

    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        guessLetterChange()
    }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        presentWord += 1
        displayImage.isHidden = true
                if presentWord == arrWords.count{
                    
                    presentWord = 0
                    WordGuessed = 0
                    RemainingWords = 0
            
                    WordGuessingUpdate(presentWord)
                    statusLabel.text = "Congratulations, You are done, Please start over again "
                    displayImage.isHidden = false
                    displayImage.image = UIImage(named:arrImages[5] )
                    playAgainButton.isHidden = false
                    count1 += 1
                    hintLabel.isHidden = true
                    userGuessLabel.isHidden = true
                    guessLetterButton.isEnabled = false
                    

                }else{
                    if(count1>0)
                    {
                        presentWord = 0
                    }
                    WordGuessingUpdate(presentWord)
                    userGuessLabel.isHidden = false
                    hintLabel.isHidden = false
                    
                    count1 = 0
                }
                updateLabels()
    }
    
    func guessLetterChange(){
        statusLabel.isHidden = false
        GuessedWordsuptoNow =  ""
                userGuessLabel.text = ""
                
                guessLetter += guessLetterField.text!.uppercased()
                for letter in arrWords[presentWord][0].uppercased(){
                    if guessLetter.contains(letter) {
                        GuessedWordsuptoNow += "\(letter)"
                        
                    }else{
                        GuessedWordsuptoNow += "_ "
                        
                    }
                }
                guessLetterField.resignFirstResponder()
                print(GuessedWordsuptoNow)
                userGuessLabel.text! = GuessedWordsuptoNow
                guessLetterField.text = ""
        GuessLetterBtndisable()
            
        GuessesUpdate()
    }
    func GuessesUpdate() {
        print("")
        if GuessedWordsuptoNow == arrWords[presentWord][0].uppercased(){
            displayImage.isHidden =  false
            WordGuessed += 1
                  
                    if presentWord == arrWords.count{
                        statusLabel.text = "congrats"
                        displayImage.image = UIImage(named:arrImages[presentWord])
                        
                    }else{
                        statusLabel.text = "This is a status lable of a App"
                        displayImage.image = UIImage(named:arrImages[presentWord])
                       
                        
                        
                    }
                    wordsGuessedLabel.text! = "Total number of words guessed successfully: \(WordGuessed)"
                    wordsRemainingLabel.text! = "Total number of words remaining in game: \(arrWords.count - WordGuessed)"
                    playAgainButton.isHidden = false
                    guessLetterField.isEnabled = false
                    
                    
                }else{
                    statusLabel.text = "This is a status lable of a App"
                    
                }
                
              
    }
                
        
    
    
    func GuessLetterBtndisable(){
        if guessLetterField.text!.count>0{
            guessLetterButton.isEnabled = true
                    let lastCharacter = guessLetterField.text!.last
                    guessLetterField.text = String(lastCharacter!).trimmingCharacters(in: .whitespaces)
                }else{
                    guessLetterButton.isEnabled = false
                }
    }
    func updateLabels(){
    
                wordsGuessedLabel.text! = "Total number of words guessed successfully: \(WordGuessed)"
                wordsRemainingLabel.text! = "Total number of words remaining in game: \(arrWords.count - WordGuessed)"
                totalWordsLabel.text! = "Total number of words in game :  \(arrWords.count)"
    }
    func WordGuessingUpdate(_ currentNumber:Int){
        userGuessLabel.text = ""
                
                for _ in 0..<arrWords[currentNumber][0].count {
                    userGuessLabel.text! += "_ "
                }
                hintLabel.text = "HINT: \(arrWords[currentNumber][1])"
                guessLetter = ""
                playAgainButton.isHidden = true
                guessLetterField.isEnabled = true
            
                
        statusLabel.text = "This is a status lable of a App"
        
    }
    @IBAction func guessLetterWordEdited(_ sender: Any) {
        GuessLetterBtndisable()
    }
    
   
}
