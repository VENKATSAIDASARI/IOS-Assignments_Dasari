//
//  ViewController.swift
//  Dasari_TicketCheckoutApp
//
//  Created by Dasari,Venkata Sai Ram on 8/12/1944 Saka.
//

import UIKit

class AvalabilityCheckViewController: UIViewController {
    
    @IBOutlet weak var airlineName: UITextField!
    
    
    @IBOutlet weak var bookingID: UITextField!
    

    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    var found = Ticket()
    var airlinenm :String = "";
    var bookingid:String = "";
    var isfound = false
     
    var  tickerArr = TicketsArray
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
    @IBAction func availabilitycheckPressed(_ sender: UIButton) {
        
        let enteredAirline = airlineName.text!
        let enteredBookingID = bookingID.text!
        for ticket in TicketsArray
        {
            if(enteredAirline == ticket.bookingID && enteredBookingID == ticket.bookingID){
                
                found = ticket
                isfound = true
                statusLabel.text! = "\(enteredBookingID)is found"
                     
                        }
        }
        
    }
    
    
    @IBAction func checkoutPressed(_ sender: UIButton) {
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            
            //We need to view courses of the logged in student in CourseViewController,
            // So we pass the courses from the 'studentObj' variable
            if transition == "checkoutSegue" {
                let destination = segue.destination as! CheckoutTicketViewController
                
                //we will assign the courses to 'courseArray' in the CourseViewController
                var statuspassed = 
            }
        }
    

}

