//
//  ECSubVC.swift
//  BearcatWiki
//
//  Created by Dasari,Venkata Sai Ram on 9/13/1944 Saka.
//

import UIKit

class ECSubVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    var itemname : ExtraCircular?
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ECsec.count;
    }
    
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            var prototypeCell = ECSubTableView.dequeueReusableCell(withIdentifier: "ECActivityCell", for: indexPath)
            prototypeCell.textLabel?.text = itemname!.items_Array2[indexPath.row].itemName
            return prototypeCell
        }
    
    
    
    
    
    

    @IBOutlet weak var ECSubTableView: UITableView!
    
    
    
    var ECsec = EcSec
    var ECSubSecItems = ECESubSection()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ECSubTableView.delegate = self
        ECSubTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ECResultSegue"{
            let destination = segue.destination as! ECResultVC
            destination.iteminfo = itemname!.items_Array2[(ECSubTableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
