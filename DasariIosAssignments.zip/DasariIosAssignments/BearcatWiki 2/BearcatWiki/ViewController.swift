//
//  ViewController.swift
//  BearcatWiki
//
//  Created by  Dasari,Venkata Sai Ram on 11/17/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBOutlet weak var studentJourney: UITextField!
    
    
    
    @IBOutlet weak var descreptionTextField: UITextView!
    
    
    @IBOutlet weak var logoImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   
    
    @IBAction func buttonClicked(_ sender: UIButton) {
    }
    
    
    
}

