//
//  ECResultVC.swift
//  BearcatWiki
//
//  Created by Dasari,Venkata Sai Ram on 9/13/1944 Saka.
//

import UIKit

class ECResultVC: UIViewController {

    var iteminfo : ECESubSection?
    @IBOutlet weak var ECImageView: UIImageView!
    
    
    
    @IBOutlet weak var ECInfoOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ECImageView.image = UIImage(named: iteminfo!.itemImage)
        ECInfoOutlet.text =  iteminfo!.itemInfo;
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
