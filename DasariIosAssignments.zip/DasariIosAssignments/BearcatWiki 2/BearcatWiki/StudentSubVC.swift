//
//  StudentSubVC.swift
//  BearcatWiki
//
//  Created by  Dasari,Venkata Sai Ram on 12/3/22.
//

import UIKit

class StudentSubVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var itemname : Study?
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var prototypeCell = StudentSubTableView.dequeueReusableCell(withIdentifier: "AcitivityCell", for: indexPath)
        prototypeCell.textLabel?.text = itemname!.items_Array[indexPath.row].itemName
        return prototypeCell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        Studysec.count;
    }
   
    

    var Studysec = StudySec
    var StudySubSecItems = StudySubSection()
    
    
    @IBOutlet weak var StudentSubTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StudentSubTableView.delegate = self
        StudentSubTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue"{
            let destination = segue.destination as! ResultViewController
            destination.iteminfo = itemname!.items_Array[(StudentSubTableView.indexPathForSelectedRow?.row)!]
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
