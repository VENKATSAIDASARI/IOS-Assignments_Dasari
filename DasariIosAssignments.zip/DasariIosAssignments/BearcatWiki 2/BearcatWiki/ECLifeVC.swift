//
//  ECLifeVC.swift
//  BearcatWiki
//
//  Created by Dasari,Venkata Sai Ram on 9/13/1944 Saka.
//

import UIKit

class ECLifeVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ECsec.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var prototypeCell = ECLifeTableView.dequeueReusableCell(withIdentifier: "ECCategoryCell", for: indexPath)
        prototypeCell.textLabel?.text = ECsec[indexPath.row].ECESub
        return prototypeCell
    }
    

    var ECsec = EcSec
    var ECSectionItems = ExtraCircular()
    
    
    
    @IBOutlet weak var ECLifeTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ECLifeTableView.delegate = self
        ECLifeTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ECActivitySegue"{
            let destination = segue.destination as! ECSubVC
            destination.itemname = ECsec[(ECLifeTableView.indexPathForSelectedRow?.row)!]
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
