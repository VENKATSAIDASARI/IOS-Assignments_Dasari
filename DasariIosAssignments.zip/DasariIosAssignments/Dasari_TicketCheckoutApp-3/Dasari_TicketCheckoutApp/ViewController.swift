//
//  ViewController.swift
//  Dasari_TicketCheckoutApp
//
//  Created by Dasari,Venkata Sai Ram on 8/12/1944 Saka.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

