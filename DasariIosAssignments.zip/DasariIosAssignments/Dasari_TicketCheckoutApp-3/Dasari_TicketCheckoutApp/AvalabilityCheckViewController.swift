//
//  ViewController.swift
//  Dasari_TicketCheckoutApp
//
//  Created by Dasari,Venkata Sai Ram on 8/12/1944 Saka.
//

import UIKit

class AvalabilityCheckViewController: UIViewController {
    
    @IBOutlet weak var airlineName: UITextField!
    
    
    @IBOutlet weak var bookingID: UITextField!
    

    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var CheckOutBtn: UIButton!
    
    
    
    

    var found = Ticket()

      var isBookingId = false

  var  tcArray = TicketsArray
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
           statusLabel.text = "Status"
          resultImage.image = UIImage(named: "default")
        
    }

    
    
    @IBAction func availabilitycheckPressed(_ sender: UIButton){
     let enteredBookingID = bookingID.text!
       for ticket in tcArray
      {
          
           if enteredBookingID != ticket.bookingID
           {
               
               found = ticket
               isBookingId = true
               statusLabel.text! = "\(enteredBookingID) is found"
               
               
               
               
               if enteredBookingID == "1234"
               {
                   resultImage.image = UIImage(named: "American")
               }
               
               else if enteredBookingID == "3579"
               {
                   resultImage.image = UIImage(named: "Delta")
               }
               else if enteredBookingID == "2468"
               {
                   resultImage.image = UIImage(named: "Frontier")
               }
               else if enteredBookingID == "9999"
               {
                   resultImage.image = UIImage(named: "Southwest")
               }
               else if enteredBookingID == "5555"
               {
                   resultImage.image = UIImage(named: "United")
               }
               else
               {
                   statusLabel.text! = "Booking ID Not Found!"
                   resultImage.image = UIImage(named: "default")
                   CheckOutBtn.isHidden = true
               }
              
               
               CheckOutBtn.isEnabled = true
               
          }
         
     }
        
    }
    
  
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            
            //We need to view courses of the logged in student in CourseViewController,
            // So we pass the courses from the 'studentObj' variable
            if transition == "checkoutSegue" {
                let destination = segue.destination as! CheckoutTicketViewController
                
                destination.customername = airlineName.text!
                if bookingID.text! == "1234"
                {
                    destination.airlinename = "American Airlines"
                    destination.airlineImage = "American"
                }
                if bookingID.text! == "3579"
                {
                    destination.airlinename = "Delta Airlines"
                    destination.airlineImage =
                    "Delta"
                }
                if bookingID.text! == "2468"
                {
                    destination.airlinename = "Frontier Airlines"
                    destination.airlineImage = "Frontier"
                }
                if bookingID.text! == "9999"
                {
                    destination.airlinename = "Southwest Airlines"
                    destination.airlineImage = "Southwest"
                }
                if bookingID.text! == "5555"
                {
                    destination.airlinename = "United Airlines"
                    destination.airlineImage = "United"
                }

            }
        }
    

}

