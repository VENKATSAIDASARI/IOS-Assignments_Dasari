//
//  ViewController.swift
//  Dasari_BillApp
//
//  Created by Pati,Usha R on 10/4/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var appName: UILabel!
    
    
    @IBOutlet weak var productNameinput: UITextField!
    
    
    
    @IBOutlet weak var noOfUnitsinput: UITextField!
    
    
    @IBOutlet weak var beforeDiscount: UILabel!
    
    
    @IBOutlet weak var afterDiscount: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func productCost(_ sender: UIButton) {
        var name = productNameinput.text!;
        var count = noOfUnitsinput.text!;
        var totalcost:Double = 0;
        var tcdiscount:Double = 0;
        var c:Int = Int(count)!;
        if name == "Perfume"
        {
            totalcost = Double(10 * c);
            tcdiscount = totalcost - totalcost * (2/100)
        }
        else if name == "T-Shirt"
        {
            totalcost = Double(35 * c);
            tcdiscount = totalcost - totalcost * (4/100);
        }
        else{
            print("enter valid input")}
        
        beforeDiscount.text = " Total price before discount for \(name) is $ \(totalcost)"
        afterDiscount.text = "Total price afger discount for \(name) is $ \(tcdiscount)"
        
        
        
    }
    
    
    
}

