//
//  ViewController.swift
//  Dasari_Calculator
//
//  Created by Dasari,Venkata Sai Ram on 9/27/22.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var displayLabelL: UILabel!
    
    var firstOperator = ""
    var secondOperator = ""
    var output = ""
    var action = ""
    var actionChanged = false
    var currentOperator = ""
    var mode = false
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttonAC(_ sender: UIButton) {
        ResetAll()
    }
    
    
    
    @IBAction func buttonC(_ sender: UIButton) {
        
        secondOperator = ""
        displayLabelL.text = ""
    }
    
    
    
    @IBAction func buttonPlusMinus(_ sender: UIButton) {
        
        if firstOperator == ""{
            displayLabelL.text = "-" + displayLabelL.text!
            firstOperator = "\(displayLabelL.text!)"
        }
        else{
            displayLabelL.text = "+" + displayLabelL.text!
            secondOperator = "\(displayLabelL.text!)"
        }
        
    }
    
    
    
    
    @IBAction func buttonDivision(_ sender: UIButton) {
        var bd = divFunction(action)
       
                action = "/"
        displayLabelL.text = ( bd != "") ? outputFormatt(bd) : ""
                if bd != "" {
                    //            inChainmode = true
                    if secondOperator != ""{
                        mode = true
                        //            number1 = temp
                        if actionChanged {
                            output = String(Double(bd)! / Double(secondOperator)!)
                            print(output)
                            if output == "inf"{
                                displayLabelL.text! = "Error"
                            }else{
                                displayLabelL.text! = outputFormatt(output)
                            }
                        }
                    }
                }
                actionChanged = true
    }
    
    
    
    
    @IBAction func button8(_ sender: UIButton) {
        assignValue("8")
    }
    @IBAction func button9(_ sender: UIButton) {
        assignValue("9")    }
    @IBAction func button6(_ sender: UIButton) {
        assignValue("6")    }
    @IBAction func button5(_ sender: UIButton) {
        assignValue("5")    }
    @IBAction func button4(_ sender: UIButton) {
        assignValue("4")    }
    @IBAction func button3(_ sender: UIButton) {
        assignValue("3")
        
    }
    @IBAction func button2(_ sender: UIButton) {
        assignValue("2")
        
    }
    @IBAction func button1(_ sender: UIButton) {
        assignValue("1")    }
    
    @IBAction func button0(_ sender: UIButton) {
        assignValue("0")
        
    }
    @IBAction func buttonDot(_ sender: UIButton) {
        
        assignValue(".")    }
    @IBAction func buttonModular(_ sender: UIButton) {
        let ram = divFunction(action)
        print("temp is \(ram)")
        action = "%"
        currentOperator=""
        displayLabelL.text = (ram != "") ? outputFormatt(ram) : ""
         
        actionChanged = true
        
    }
    
    
    
    @IBAction func buttonEqual(_ sender: UIButton) {
        var res = ""
        switch action {
        case "+":
            
            if currentOperator != "" {
                res = String(Double(firstOperator)! + Double(currentOperator)!)
                displayLabelL.text = outputFormatt(res)
                 secondOperator = currentOperator
            }else{
                res = String(Double(firstOperator)! + Double(secondOperator)!)
                displayLabelL.text = outputFormatt(res)
            }
            firstOperator = res
            
            break
        case "*":
            if currentOperator != "" {
                res = String(Double(firstOperator)! * Double(currentOperator)!)
                displayLabelL.text = outputFormatt(res)
               
            }else{
                res = String(Double(firstOperator)! * Double(secondOperator)!)
                displayLabelL.text = outputFormatt(res)
            }
            firstOperator = res
            
            break
        case "-":
            if currentOperator != "" {
                res = String(Double(firstOperator)! - Double(currentOperator)!)
                displayLabelL.text = outputFormatt(res)
               
            }else{
                res = String(Double(firstOperator)! - Double(secondOperator)!)
                displayLabelL.text = outputFormatt(res)
            }
            firstOperator = res
            break
        case "/":
            if displayLabelL.text == "Error"{
                ResetAll()
            }else{
                if currentOperator != "" {
                    res = String(Double(firstOperator)! / Double(currentOperator)!)
                    if res == "inf"{
                        displayLabelL.text! = "Error"
                        return
                    }else{
                        displayLabelL.text = outputFormatt(res)
                    }
                }else{
                    res = String(Double(firstOperator)! / Double(secondOperator)!)
                    if res == "inf"{
                        displayLabelL.text! = "Error"
                        return
                    }else{
                        displayLabelL.text = outputFormatt(res)
                    }
                }
                firstOperator = res
            }
            break
        case "%":
            if currentOperator != "" {
                displayLabelL.text = outputFormatt(res)
                let s1 = Double(firstOperator)!
                let s2 = Double(currentOperator)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                 secondOperator = currentOperator
            }else{
                let s1 = Double(firstOperator)!
                let s2 = Double(secondOperator)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                displayLabelL.text = outputFormatt(res)
            }
            firstOperator = res
            
            break
        default:
            displayLabelL.text = "No data to display"
        }
        
        
    }
    @IBAction func buttonPlus(_ sender: UIButton) {
        
        let ram = divFunction(action)
        print("temp is \(ram)")
        action = "+"
        currentOperator=""
        displayLabelL.text = (ram != "") ? outputFormatt(ram) : ""
       
        actionChanged=true
    }
    
    
    @IBAction func buttonMinus(_ sender: UIButton) {
        
        let ram = divFunction(action)
        action = "-"
        displayLabelL.text = (ram != "") ? outputFormatt(ram) : ""
        if ram != "" {
            //            inChainmode = true
            if secondOperator != ""{
                mode = true
                currentOperator = secondOperator;
                if actionChanged {
                    output = String(Double(ram)! - Double(secondOperator)!)
                    displayLabelL.text! = outputFormatt(output)
                }
            }
        }
        actionChanged = true
        
    }
    
    
    @IBAction func buttonCross(_ sender: UIButton) {
        
        let ram = divFunction(action)
        print("temp is \(ram)")
        action = "*"
        currentOperator=""
        displayLabelL.text = (ram != "") ? outputFormatt(ram) : ""
        
        actionChanged=true    }
    
    @IBAction func button7(_ sender: UIButton) {
        assignValue("7")
        
    }
    func ResetAll(){
        secondOperator = ""
        firstOperator = ""
        actionChanged = false
        action = ""
        currentOperator = ""
        displayLabelL.text = "0"
        // lShow.textColor = .red
        mode=false
    }
    
    
    func divFunction(_ operation:String)->String {
        print("\(firstOperator),\(secondOperator)")
        if firstOperator != "" && secondOperator != ""{
            if action == "+"{
                firstOperator = String(Double(firstOperator)! + Double(secondOperator)!)
                currentOperator = secondOperator
                secondOperator = ""
                return String(firstOperator)
                
            }
            if action == "-"{
                firstOperator = String(Double(firstOperator)! - Double(secondOperator)!)
                currentOperator = secondOperator
                secondOperator = ""
                return String(firstOperator)
            }
            if action == "*"{
                firstOperator = String(Double(firstOperator)! * Double(secondOperator)!)
                currentOperator = secondOperator
                secondOperator = ""
                return String(firstOperator)
            }
            if action == "/"{
                firstOperator = String(Double(firstOperator)! / Double(secondOperator)!)
                currentOperator = secondOperator
                secondOperator = ""
                return String(firstOperator)
            }
            if action == "%" {
                let s = Double(firstOperator)!
                let a = Double(secondOperator)!
                var i = s.remainder(dividingBy: a)
                firstOperator = String(i)
                currentOperator = secondOperator
                secondOperator = ""
                return String(firstOperator)
            }
        }
        return ""
    }
    
    func outputFormatt(_ output:String)->String {
        let ram = Double(output)!
        var opStr = String(round(ram * 100000) / 100000.0)
        
        if opStr.contains(".0"){
            opStr.removeSubrange(opStr.index(opStr.endIndex, offsetBy: -2)..<opStr.endIndex)
        }
        
        return opStr
    }
    func assignValue(_ number: String){
        if displayLabelL.text == "0"{
            displayLabelL.text = ""
          
        }
        if !actionChanged {
            displayLabelL.text! += number
            firstOperator += number
        }else{
            print(mode)
            if !mode {
                displayLabelL.text! += number
                secondOperator += number
            }else {
                displayLabelL.text = ""
                displayLabelL.text! += number
                secondOperator += number
            }
        }
    }
    
}

