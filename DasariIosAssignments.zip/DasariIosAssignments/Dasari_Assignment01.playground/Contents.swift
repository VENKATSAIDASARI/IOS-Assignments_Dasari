import UIKit
//Venkata Sai Ram Dasari s547046

/*
When you open this file  in Xcode, it is normal that you see errors in the source code.
 */
//**************** QUESTION 1 ****************
// 1.a) Declare two variables called  distance1 and distance2 of type Double and assign your own values to them and also add 2 declared variables and print output.

var distance1:Double = 10.0;
var distance2:Double = 20.0;
print(distance1+distance2);


// 1.b) Declare a constant called  maxWeight of type Int and assign with a value of 130, using type annotation

let maxWeight:Int = 130;


// 1.c) Print  "Your max weight is xxxx pounds", replacing the xxxx with the value of maxWeight. Use String interpolation

print("Your max weight is \(maxWeight) pounds")


// 1.d) Write Swift source code to print the below in one single print statement
print("Hello, All \rWelcome to Swift programming");
/*
                Hello, All
                Welcome to Swift Programming..!
            */


//**************** END OF QUESTION 1 ****************

print("_____________________________________________")

//**************** QUESTION 2 ****************
// 2.a) Predict what will happen when you try and execute below three statements when you uncomment the third line? comment your prediction

var x:Double = 15
var y = 25.0
y = x
//y=x
// Herevariable x is of type Int and variable y is of type Double which Results in error because we cannot assign Integer type value to Double type


// 2.b) Fix the error in the question 2.a


y = Double(x);

// or we can declare both variable as Double and then assigning y=x also solves the problem
// var x:Double=15
//var y = 25.0
// y=x In this way also we can resolve the error

//**************** END OF QUESTION 2 ****************
print("_____________________________________________")

//**************** QUESTION 3 ****************
//3.a) Declare three constants x, y, z and assign the values 2, 7, 5. Write a swift code to find the largest number among the three integers.
//we already declared variables x and y so we cannot declare again. So i am using X and Y and Z instead
let X = 2;
let Y = 7;
let Z = 5;
if(X>Y&&X>Z)
{
    print("Largest number is X");
}
else if(Y>Z)
{
    print("Largest number is Y")
}
else
{
    print("Largest number is Z")
}
//3.b) Declare 2 variables a,b and assign values 13, 103. Write a swift code to check whether the last digit of the two given integer values are same or not.

var a = 13;
var b = 103;
if(a%10==b%10)
{
    print("The last two digits of two given numbers are same")
}
else
{
    print("The last two digits of two given numbers are not same")
}

//**************** END OF QUESTION 3 ****************

print("_____________________________________________")
//**************** QUESTION 4 ****************
//using loops
//4.a) Print the numbers 1 to N in alternative order, one number from the left side (starting with one) and one number from the right side (starting from N down to 1)
//Decalare var N = 10
//expected output is 1 15 2 14 3 13 4 12 5 11 6 10 7 9

var N = 10

var numbers = stride(from: 1, through: 5, by: 1)

for i in numbers {
    print(i, N, terminator: " ")
    N = N-1
}

print("\n")
//4.b) If a number C is given, then print the following half rhombus
//declare C = 5
//output
// Hint : use terminator in print statements and loops

//    *
//   ***
//  *****
// *******
//*********
// *******
//  *****
//   ***
//    *

var C = 5;

var p:Int;
for p in 1...5
{
    print(String.init(repeating: " ",count:5-p)+String.init(repeating: "*", count: 2*p - 1 ))
}
var q:Int = 4 ;
for p in 1...4
{
    print(String.init(repeating: " ", count: p )+String.init(repeating: "*",count: 2*q - 1)+String.init(repeating: " ", count: p-1 ))
    q-=1;
}
//**************** END OF QUESTION 4 ****************

print("_____________________________________________")
//**************** QUESTION 5 ****************
// Using Strings
//5.a) Declare a String and assign the value of your own, Write a Swift code to add "A" in front of the string and print it. If the string already begins with "A", then simply print it.

var name:String = "ir india is owned by Tata"

if(name[name.startIndex]=="A")
{
    print(name)
}
else
{
name.insert(contentsOf: "A" ,at: name.startIndex )
    print(name)
}

//5.b) Declare a String str1 and and assign the value of your own. Write a swift code to add the last character at the front and back of the given string and print it.
var str1:String = "India"
var str2:Character=str1[str1.index(str1.endIndex,offsetBy: -1)]
str1.insert(str2, at: str1.startIndex)
str1.insert(str2, at: str1.endIndex)
print(str1)

//print(str1.appen)
//str1.insert(contentsOf: str2, at: str1.startIndex, at: str1.endIndex)
//str1.insert(contentsOf: str2, at: str1.startIndex)


//5.c) Declare a String 'Swift' and print them in the reverse order.

var str3:String = "Swift"
var reverse=String(str3.reversed())
print(reverse);
//5.d) Write a Swift code  to check if the first or last characters are 'a' of a given string, return the given string without those 'a' characters in the first and last, otherwise return the given string.
 //declare var myString1 = "ababa"
 //expected output bab
var myString1:String = "ababa"
if(myString1[myString1.startIndex]=="a"||myString1.suffix(1)=="a")
{
    myString1.remove(at: myString1.startIndex);
    myString1.removeLast();
    print(myString1)
}
    

else
{
    print(myString1)
}
//**************** END OF QUESTION 5 ***``*************
print("_____________________________________________")
 



